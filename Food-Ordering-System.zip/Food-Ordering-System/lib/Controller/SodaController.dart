import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:Pizza/Controller/PizzaController.dart';
import 'package:Pizza/ModelClass/FoodItemModel.dart';

class SodaController extends GetxController {



}
