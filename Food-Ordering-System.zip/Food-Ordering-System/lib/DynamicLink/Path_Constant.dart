

const String kUriPrefix = "https://pizzadynamiclink.page.link";
const String kAboutpage = "/aboutpage";
const String kLikepage = "/likepage";

