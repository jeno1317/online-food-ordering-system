
class BoardingModelClass {
  late String lottiefile;
  late String title;
  late String subtitle;

  BoardingModelClass(
      {required this.title, required this.lottiefile, required this.subtitle});
}


