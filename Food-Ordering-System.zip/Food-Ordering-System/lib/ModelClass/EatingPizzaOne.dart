class EatingPizzaOne{
  String ?image;
  String ?pizza;
  String ?name;

EatingPizzaOne({required this.image,required this.name,required this.pizza});
}