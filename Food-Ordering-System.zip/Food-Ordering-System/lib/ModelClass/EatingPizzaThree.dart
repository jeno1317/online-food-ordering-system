class EatingPizzaThree{
  String ?image;


  EatingPizzaThree({required this.image});
}