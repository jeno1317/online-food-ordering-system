class EatingPizzaTwo{
  String ?image;

  EatingPizzaTwo({required this.image});
}