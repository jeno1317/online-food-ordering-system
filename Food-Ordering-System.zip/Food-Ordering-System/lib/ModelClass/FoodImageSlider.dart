class FoodImageSlider {
  String? image;
  String? tital;
  String? offer;
  String? description;
  String? order;

  FoodImageSlider(
      {required this.image,
      required this.description,
      required this.offer,
      required this.order,
      required this.tital});
}
