import 'package:flutter/cupertino.dart';

class HomeCetegorieModel {
  String? name;
  String? image;
  Widget? navigate;
  int ?index;

  HomeCetegorieModel(
      {required this.name, required this.image, required this.navigate,required this.index});
}
