class OfferModel{
  String? name;
  String? subname;
  String? image;
  bool apply=false;
  bool check=false;
  bool button=false;

  OfferModel({required this.name, required this.subname, required this.image,required this.button});

}
