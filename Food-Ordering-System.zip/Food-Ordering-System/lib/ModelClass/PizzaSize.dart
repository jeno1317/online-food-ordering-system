class PizzaSize{
  String name="";
  bool check=false;

  PizzaSize({required this.name,required this.check});
}
